# Changelog

## 0.1.0 — 2026-09-02

- Initial public Windows-only release.
- Chinese WinForms interface with English application branding.
- Automatic local reset detection and manual five-hour scheduling.
- Native `HH:mm` time picker and configurable safety buffer.
- Portable Desktop shortcut installer and uninstaller.
- Local-only state storage and Codex executable discovery.
