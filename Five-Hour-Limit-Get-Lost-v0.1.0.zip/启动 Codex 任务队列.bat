@echo off
wscript.exe //B //Nologo "%~dp0启动 Codex 任务队列.vbs"
