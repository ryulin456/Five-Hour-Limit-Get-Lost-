@echo off
wscript.exe //B //Nologo "%~dp0start-five-hour-limit-get-lost.vbs"
